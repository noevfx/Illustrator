# Illustrator MCP & CEP Extension — Diretrizes do Projeto
// Herda as Diretrizes Globais de D:\.IA agents\global\AGENTS.md e o manual D:\.IA agents\manuais\IL_PATTERNS.md
// Versão do projeto travada em 1.0.0 até ordem do usuário.

## Estrutura Obrigatória

```
Illustrator MCP & CEP Extension\
├── CEP Extension\        ← Extensão CEP (com.ilmcp.bridge)
│   ├── CSXS\manifest.xml
│   ├── js\main.js        ← Polling Node/CEF
│   ├── jsx\host.jsx      ← ilmcp_runTask() ExtendScript ES3
│   └── index.html
├── MCP Server\           ← Servidor Node.js MCP
│   ├── index.js          ← Entry MCP (todas as tools)
│   ├── il-runner.js      ← Comunicação via task/result JSON
│   ├── tools.js          ← Geração de código ExtendScript
│   ├── package.json
│   └── .il_bridge\       ← task.json / result.json (runtime)
├── instaladores\         ← install.ps1 e uninstall.ps1
│   ├── install.ps1
│   └── uninstall.ps1
├── scripts\              ← package-zip.ps1 (grava em ..\release\IL MCP Bridge\vX.Y.Z\)
├── README.md
├── VERSIONING.md
└── AGENTS.md             ← este arquivo
```

## Regras de Código

### ExtendScript (host.jsx + tools.js)
- **Consulte sempre `D:\.IA agents\manuais\IL_PATTERNS.md`** para padrões de design vetorial, hierarquia de camadas e traçados.
- **ES3 estrito**: `var`, `function`, sem `let`, `const`, arrow functions
- **Padrão de traçado**: `StrokeCap.ROUNDENDCAP` e `StrokeJoin.ROUNDENDJOIN`
- **Escala de traço**: sempre ativar `app.preferences.setBooleanPreference("scaleStrokes", true)`
- Sem `JSON.parse`/`JSON.stringify` direto em loops críticos — sempre `try/catch`
- Sem `Array.forEach`, `.map`, `.filter` — usar `for` clássico
- Sem vírgulas sobrando (trailing commas)
- Comentários em PT-BR

### Node.js (index.js, il-runner.js, tools.js)
- CommonJS (`require`/`module.exports`), sem TypeScript, sem compilação
- `path.join()` em todos os caminhos — nunca concatenar strings
- Versionamento no topo: `// Version: X.Y.Z`

## Versionamento (SemVer)
- `PATCH (1.0.x)`: Correções, ajustes de ExtendScript, fixes de path
- `MINOR (1.x.0)`: Novas tools, novos scripts, novos recursos
- `MAJOR (x.0.0)`: Quebra de API, mudança de arquitetura

Ao versionar:
1. Atualizar `MCP Server/package.json` → campo `"version"`
2. Atualizar cabeçalho `// Version: X.Y.Z` nos arquivos alterados
3. Rodar `scripts\package-zip.ps1` → gera ZIP; o zip vai para `..\release\IL MCP Bridge\vX.Y.Z\` (nunca sobrescreve)
4. Commit: `release: vX.Y.Z — <descrição>`

## Instalação e Distribuição
- **Auto-install**: `instaladores\install.ps1` (duplo clique, sem admin)
- **Desinstalar**: `instaladores\uninstall.ps1`
- **Gerar ZIP**: `scripts\package-zip.ps1` (ou `.\package-zip.ps1 -Version "1.0.1"`)
- **Distribuir**: enviar o ZIP — receptor roda `install.ps1`

## Comunicação CEP ↔ MCP
- `CEP Extension/js/main.js` monitora 2 dirs:
  - `%TEMP%\il_bridge\` (acesso universal)
  - `MCP Server/.il_bridge\` (fallback local)
- Protocolo: escreve `task.json {id, code}` → panel executa → escreve `result_<id>.json {success, data, error}`
- Timeout CEP: 6s | Timeout Node: 8s

## Quando o Agente Faz Mudanças
1. Modificar apenas os arquivos necessários (escopo cirúrgico)
2. Incrementar versão PATCH ou MINOR conforme a natureza da mudança
3. Se mudou a extensão CEP: reinstalar copiando `CEP Extension/` para `%APPDATA%\Adobe\CEP\extensions\com.ilmcp.bridge`
4. Se mudou o servidor MCP: atualizar config em `~/.gemini/antigravity/config/mcp_servers.json`
5. Rodar `package-zip.ps1` para gerar a nova versão em release\

## Tools Registradas (51)
il_get_document_info, il_execute_script, il_get_layers, il_create_layer,
il_delete_layer, il_set_layer_visibility, il_lock_layer, il_move_layer,
il_get_selection, il_select_all, il_deselect, il_select_by_name,
il_create_rectangle, il_create_ellipse, il_create_path, il_create_text,
il_update_text, il_set_fill_color, il_set_stroke_color, il_set_stroke_width,
il_apply_opacity, il_group_selection, il_ungroup_selection, il_move_selection,
il_resize_selection, il_rotate_selection, il_align_objects, il_distribute_objects,
il_get_artboards, il_add_artboard, il_set_active_artboard, il_export_svg,
il_export_png, il_export_pdf, il_save_document, il_open_document,
il_close_document, il_create_document, il_get_swatches, il_add_guide,
il_clear_guides, il_get_symbols, il_place_image, il_apply_effect,
il_get_fonts, il_duplicate_selection, il_bring_to_front, il_send_to_back,
il_fit_artboard_to_artwork, il_zoom_to_fit, il_run_jsx_file
